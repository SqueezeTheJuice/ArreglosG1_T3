package com.mycompany.memoriag1;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author javie
 */
public class Principal {
    new object Dispatcher
            
public void retiradememoriaU(){
    dispatcher 
}
public void reducetiempo(){
    procesador.procesaprocesos(memoria);
}

public void retiradememoria(){
    Proceso p = dispatcher.retiradememora()
       
}
    

////que se vea el tiempo,pintR DE COLORES la lista
/////hacer otro algoritmo, cambio  de algoritmo,reloj para que termine a los 5 segundos