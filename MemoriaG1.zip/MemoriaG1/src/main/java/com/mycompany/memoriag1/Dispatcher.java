package com.mycompany.memoriag1;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author javie
 */
public class Dispatcher {
    int mp = 0;
    for(JLabel m : memorias){
    if(m.getBackroumd()== Color.cyan){
    m.setBackround(p.getColor();
    m.setText(p.getDuracionmemoria()+"");
    mp++;
    if(mp>=o.getTamanomemoria()){
    p.getEstado("Ejecutandose");
    if(p.getRecursocritico()=null){
    p.getRecusocritico().incrfementarprocesos;
}
    return true;
}
}
}
    return fale;
    
    
                
public proceso retiradememoriaU(){
    for(JLabel m : memorias){
        if(m.getText().equals("0")){
            c=m.getBackround();
            m.setBackround(Color.cyan);
            m.setText("");
        
    }
}
    for(proceso p:Procesos){ 
        if(p.getColor()==c)
            ´p.setEstado("Terminado");
    }
}
