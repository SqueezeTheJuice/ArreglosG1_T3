package com.mycompany.memoriag1;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author javie
 */
public class Recurso {
    private String nombre;
    private int procesospermitidos;
    private int numerosprocesoutilizados;
    private boolean desbloqueado = true;
   
    public void IncrementarProcesosutilizados(){
        if(desbloqueado)
        {
            this.numerosprocesoutilizados++;
            if(this.numerosprocesoutilizados)
        }
    }
    
    public Recurso()
    {
        this.nombre=noimbre;
        this.procesospermitidos = Global.Rand();
    }