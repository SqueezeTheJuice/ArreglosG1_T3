package com.mycompany.memoriag1;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author javie
 */
public class Scheduler {

    private scheduler instancia = null:;
    private Scheduler singleton(){
        if (instancia == null){
            instancia = new Scheduler();
        }
        return instancia;
    }
    private Scheduler(){
        
    }
    
    public void eligeproceso(ArrayList){
        int mp=0;
            if(Global.getAlgoritmo().equals("FCFS")){
            for(Procerso p: procesos){
                    
            if(p.getEstado().equals("Listo")&& p.getTamanomemoria()){
                if(p.Recursocritico()==null{
                    return p;
                }

            }else{ 
                if(p.get 
                        )
        }else{
    }
            }
}
    }
}