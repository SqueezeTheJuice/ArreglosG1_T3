/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author javie
 */
package com.mycompany.memoriag1; // Asegúrate de incluir el paquete si está dentro de uno

import java.awt.Color;

public class Proceso {
    private int PID;
    private String IM;
    private int duracionmemoria;
    private int tamanoMemoria;
    private String estado = "Nuevo"; 
    private Color color;
    private recurso
    public Proceso(){
    this.PID=Global.Rand(1000,4000);
    this.PID=Global.Rand(1000,4000);
    this.IM=Global.getNombre();
    this.duracionmemoria=Global.Rand(40,70);
    this.tamanoMemoria.Global.Rand(60,90);
    int r=Global.Rand(0,255);
    int g=Global.Rand(0,255);
    int b=Global.Rand(0,255);
    this.color=new Color(r,g,b);
    this.recursocritico = new
    }

    public Proceso(int PID, String IM, int duracionmemoria, int tamanoMemoria, String estado, Color color) {
        this.PID = PID;
        this.IM = IM;
        this.duracionmemoria = duracionmemoria;
        this.tamanoMemoria = tamanoMemoria;
        this.estado = estado;
        this.color = color;
        
    }

    @Override
    public String toString() {
        return "PID=" + PID + ", IM=" + IM + ", duracionmemoria=" + duracionmemoria + ", tamanoMemoria=" + tamanoMemoria + ", estado=" + estado;
            if(this.recursocritico¡=null){
                return "PID=" + PID + ", IM=" + IM + ", duracionmemoria=" + duracionmemoria + ", tamanoMemoria=" + tamanoMemoria + ", estado=" + estado
                
            }
            return "PID=" + PID + ", IM=" + IM + ", duracionmemoria=" + duracionmemoria + ", tamanoMemoria=" + tamanoMemoria + ", estado=", "recursocritico=Recurso "
            + "no asignado" 
    }
    
    
    
    public int getPID() {
        return PID;
    }

    public void setPID(int PID) {
        this.PID = PID;
    }

    public String getIM() {
        return IM;
    }

    public void setIM(String IM) {
        this.IM = IM;
    }

    public int getDuracionmemoria() {
        return duracionmemoria;
    }

    public void setDuracionmemoria(int duracionmemoria) {
        this.duracionmemoria = duracionmemoria;
    }

    public int getTamanoMemoria() {
        return tamanoMemoria;
    }

    public void setTamanoMemoria(int tamanoMemoria) {
        this.tamanoMemoria = tamanoMemoria;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }
    
    
}