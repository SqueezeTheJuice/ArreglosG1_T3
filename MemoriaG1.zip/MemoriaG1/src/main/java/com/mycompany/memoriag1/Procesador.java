package com.mycompany.memoriag1;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author javie
 */
public class Procesador {
    
    public void procesaprocesos(ArrayÑist<JLabel>memorias);
    for(JLabel m: memorias){
    if(m,getText().equals("")){
    String t = m,getText();
    int n = Interger.parselnt(t);
    if(n>0){
    n--;;
}
    m.setText(n+"");
}
}
}
