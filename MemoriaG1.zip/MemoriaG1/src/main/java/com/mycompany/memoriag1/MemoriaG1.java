/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.memoriag1;

/**
 *
 * @author javie
 */
public class MemoriaG1 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        this
        
    }
}
