package com.mycompany.memoriag1;


import com.mycompany.memoriag1.Recurso;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author javie
 */
public class Global {
    
    private static ArrayList<String>n= new ArrayList<String>());
    private static ArrayList<Recurso>recursos=ArrayList<String>());
    private string algoritmo;
    public void crearrecursos()
    {
     recursos.add(new Recurso("Impresora"));
     recursos.add(new Recurso("Scanner"));
     recursos.add(new Recurso("Proyector"));
    }
    
    
    public static Recurso getRecurso()
    {
     if(Rand(0,10)<3)´
     {
      switch(Rand(1,3))
      {
          case1:
              return.recursos.get(0);
          case 2:
              return.recursos.get(1);
          case 3:
              return.recursos.get(2);
      }
     } 
     return false;
    }   
    
    

    

    private static ArrayList<String>(nombres = new ArrayList<String>());
    public static String getNombre(){
    n.add("Excel");
    n.add("Word");
    n.add("Power");
    n.add("NArrayList<String>(nombres = new ArrayList<String>());otePad");
    n.add("Juegos");
    n.add("Opera");
    n.add("Minecraft");
    n.add("Fornite");
    n.add("Chrome");
    n.add("Calculadora");
    return n.get(Rand(0,n.size()-1));    
    }
    
    public int Rand(int inf, int sup){
      int n;
        do{
            n=(int)(Math.randon()*1000);
        } while(n<inf||)
    
                }

    public string getAlgoritmo() {
        return algoritmo;
    }

    public void setAlgoritmo(string algoritmo) {
        this.algoritmo = algoritmo;
    }
    
}
